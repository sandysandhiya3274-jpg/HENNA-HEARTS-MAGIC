"""
tests/test_bookings.py - automated checks for bookings, validation, security and admin.

Run from the project folder:
    python -m unittest discover -s tests -v
(pytest also works if you have it installed: pytest)
Every test uses its own temporary database, so your real data is never touched.
"""
import os
import re
import sqlite3
import sys
import tempfile
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402
from models import database as db  # noqa: E402
from utils.validators import normalize_phone, validate_booking  # noqa: E402

ADMIN_USER, ADMIN_PASS = "owner", "a-long-test-password-123"


def future(days=30):
    return (date.today() + timedelta(days=days)).isoformat()


def valid_form(**overrides):
    form = {
        "full_name": "Ananya Rao", "email": "ananya@example.com", "phone": "98765 43210",
        "event_type": "Wedding", "event_date": future(), "preferred_time": "Morning (9 AM - 12 PM)",
        "location": "Grand Palace Hall, Chennai", "guest_count": "6", "service": "full-bridal",
        "notes": "Peacock motif please",
    }
    form.update(overrides)
    return form


class BaseCase(unittest.TestCase):
    csrf_on = False

    def setUp(self):
        fd, self.db_path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app({"TESTING": True, "SECRET_KEY": "test-secret", "DATABASE_PATH": self.db_path,
                               "CSRF_ENABLED": self.csrf_on})
        db.init_schema(self.db_path)
        with self.app.app_context():
            db.create_admin(ADMIN_USER, ADMIN_PASS)
        self.client = self.app.test_client()

    def tearDown(self):
        os.remove(self.db_path)

    def rows(self, sql="SELECT * FROM bookings"):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            return conn.execute(sql).fetchall()
        finally:
            conn.close()

    def login(self, client=None, password=ADMIN_PASS):
        return (client or self.client).post("/admin/login", data={"username": ADMIN_USER, "password": password})


class ValidatorTests(unittest.TestCase):
    def test_phone_formats(self):
        for good in ("9876543210", "+91 98765 43210", "098765-43210", "91 9876543210"):
            self.assertEqual(normalize_phone(good), "9876543210", good)
        for bad in ("12345", "5876543210", "98765432101", "abcdefghij", ""):
            self.assertIsNone(normalize_phone(bad), bad)

    def test_valid_booking_has_no_errors(self):
        clean, errors = validate_booking(valid_form())
        self.assertEqual(errors, {})
        self.assertEqual(clean["phone"], "9876543210")

    def test_today_is_allowed_but_yesterday_is_not(self):
        self.assertNotIn("event_date", validate_booking(valid_form(event_date=date.today().isoformat()))[1])
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        self.assertIn("event_date", validate_booking(valid_form(event_date=yesterday))[1])

    def test_rejects_bad_input(self):
        cases = {
            "email": "not-an-email", "phone": "123", "full_name": "A", "guest_count": "0",
            "event_type": "Birthday??", "service": "hacker-package", "location": "x",
            "event_date": "31-12-2030", "preferred_time": "midnight",
        }
        for field, value in cases.items():
            _, errors = validate_booking(valid_form(**{field: value}))
            self.assertIn(field, errors, field)

    def test_missing_fields_all_reported(self):
        _, errors = validate_booking({})
        for field in ("full_name", "email", "phone", "event_type", "event_date", "preferred_time",
                      "location", "guest_count", "service"):
            self.assertIn(field, errors)


class PublicPageTests(BaseCase):
    def test_all_public_pages_load(self):
        for path in ("/", "/about", "/gallery", "/services", "/style-guide", "/booking", "/contact",
                     "/admin/login", "/robots.txt", "/sitemap.xml"):
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200, path)

    def test_unknown_page_gives_friendly_404(self):
        response = self.client.get("/nope")
        self.assertEqual(response.status_code, 404)
        self.assertIn(b"404", response.data)

    def test_security_headers_present(self):
        headers = self.client.get("/").headers
        self.assertIn("script-src 'self'", headers["Content-Security-Policy"])
        self.assertEqual(headers["X-Frame-Options"], "DENY")

    def test_service_preselected_from_query(self):
        html = self.client.get("/booking?service=arabic").get_data(as_text=True)
        self.assertRegex(html, r'<option value="arabic"\s+selected>')

    def test_style_guide_recommendation(self):
        answers = {"style": "traditional", "detail": "intricate", "occasion": "bridal", "coverage": "full"}
        html = self.client.post("/style-guide", data=answers).get_data(as_text=True)
        self.assertIn("We suggest: Bridal designs", html)
        incomplete = self.client.post("/style-guide", data={"style": "modern"}).get_data(as_text=True)
        self.assertIn("answer all four questions", incomplete)

    def test_contact_form_saves_enquiry(self):
        response = self.client.post("/contact", data={"name": "Meera", "email": "m@example.com",
                                                      "phone": "", "message": "Do you travel to Madurai?"})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(len(self.rows("SELECT * FROM contact_enquiries")), 1)
        bad = self.client.post("/contact", data={"name": "M", "email": "bad", "message": "hi"})
        self.assertEqual(bad.status_code, 400)


class BookingFlowTests(BaseCase):
    def test_valid_booking_saved_and_confirmation_shown(self):
        response = self.client.post("/booking", data=valid_form())
        self.assertEqual(response.status_code, 302)
        rows = self.rows()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["status"], "Pending")
        self.assertEqual(rows[0]["phone"], "9876543210")
        self.assertRegex(rows[0]["reference"], r"^HHM-\d{6}-[A-Z0-9]{5}$")

        page = self.client.get(response.headers["Location"]).get_data(as_text=True)
        self.assertIn(rows[0]["reference"], page)
        self.assertIn("not confirmed yet", page)

    def test_confirmation_hidden_from_other_visitors(self):
        response = self.client.post("/booking", data=valid_form())
        location = response.headers["Location"]
        stranger = self.app.test_client()
        self.assertEqual(stranger.get(location).status_code, 404)

    def test_past_date_rejected_and_nothing_saved(self):
        response = self.client.post("/booking", data=valid_form(event_date="2020-01-01"))
        self.assertEqual(response.status_code, 400)
        self.assertIn(b"cannot be in the past", response.data)
        self.assertEqual(self.rows(), [])

    def test_invalid_email_and_phone_rejected(self):
        for bad in ({"email": "nope"}, {"phone": "12345"}):
            response = self.client.post("/booking", data=valid_form(**bad))
            self.assertEqual(response.status_code, 400)
        self.assertEqual(self.rows(), [])

    def test_form_values_kept_after_error(self):
        response = self.client.post("/booking", data=valid_form(email="nope", full_name="Zoya Khan"))
        self.assertIn(b"Zoya Khan", response.data)

    def test_honeypot_blocks_bots(self):
        self.client.post("/booking", data=valid_form(website="http://spam.example"))
        self.assertEqual(self.rows(), [])

    def test_save_failure_is_never_shown_as_success(self):
        self.app.config["DATABASE_PATH"] = "/nonexistent-folder/broken.db"
        response = self.client.post("/booking", data=valid_form())
        self.assertEqual(response.status_code, 500)
        self.assertIn(b"Nothing was submitted", response.data)
        self.assertNotIn(b"Your request is saved", response.data)

    def test_html_in_input_is_escaped(self):
        self.client.post("/booking", data=valid_form(notes="<script>alert(1)</script>"))
        with self.client.session_transaction() as sess:
            ref = sess["last_booking"]
        page = self.client.get("/booking/confirmation/" + ref).get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", page)
        self.assertIn("&lt;script&gt;", page)

    def test_references_are_unique(self):
        for _ in range(5):
            self.client.post("/booking", data=valid_form())
        refs = [r["reference"] for r in self.rows()]
        self.assertEqual(len(refs), len(set(refs)))


class CsrfTests(BaseCase):
    csrf_on = True

    def test_post_without_token_rejected(self):
        response = self.client.post("/booking", data=valid_form())
        self.assertEqual(response.status_code, 400)
        self.assertEqual(self.rows(), [])

    def test_post_with_token_accepted(self):
        page = self.client.get("/booking").get_data(as_text=True)
        token = re.search(r'name="csrf_token" value="([0-9a-f]+)"', page).group(1)
        response = self.client.post("/booking", data=valid_form(csrf_token=token))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(len(self.rows()), 1)

    def test_wrong_token_rejected(self):
        self.client.get("/booking")
        response = self.client.post("/booking", data=valid_form(csrf_token="forged"))
        self.assertEqual(response.status_code, 400)


class AdminTests(BaseCase):
    def make_booking(self, **overrides):
        self.client.post("/booking", data=valid_form(**overrides))
        return self.rows()[-1]

    def test_admin_pages_require_login(self):
        anon = self.app.test_client()
        for path in ("/admin/", "/admin/enquiries", "/admin/booking/1"):
            response = anon.get(path)
            self.assertEqual(response.status_code, 302, path)
            self.assertIn("/admin/login", response.headers["Location"])
        for path in ("/admin/booking/1/status", "/admin/booking/1/delete"):
            self.assertEqual(anon.post(path, data={"status": "Confirmed"}).status_code, 302, path)

    def test_password_is_hashed_in_database(self):
        stored = self.rows("SELECT password_hash FROM admin_users")[0]["password_hash"]
        self.assertNotIn(ADMIN_PASS, stored)
        self.assertTrue(stored.startswith(("scrypt:", "pbkdf2:")))

    def test_wrong_password_rejected_and_right_accepted(self):
        self.assertEqual(self.login(password="wrong").status_code, 401)
        self.assertEqual(self.client.get("/admin/").status_code, 302)
        self.assertEqual(self.login().status_code, 302)
        self.assertEqual(self.client.get("/admin/").status_code, 200)

    def test_logout_ends_session(self):
        self.login()
        self.client.post("/admin/logout")
        self.assertEqual(self.client.get("/admin/").status_code, 302)

    def test_lockout_after_repeated_failures(self):
        from routes import admin_routes
        admin_routes._failed_logins.clear()
        for _ in range(self.app.config["LOGIN_MAX_ATTEMPTS"]):
            self.login(password="wrong")
        self.assertEqual(self.login().status_code, 429)  # even the right password is refused
        admin_routes._failed_logins.clear()

    def test_dashboard_stats_and_status_update(self):
        booking = self.make_booking()
        self.login()
        html = self.client.get("/admin/").get_data(as_text=True)
        self.assertIn(booking["reference"], html)
        self.client.post("/admin/booking/%d/status" % booking["id"], data={"status": "Confirmed"})
        self.assertEqual(self.rows()[0]["status"], "Confirmed")
        self.client.post("/admin/booking/%d/status" % booking["id"], data={"status": "Hacked"})
        self.assertEqual(self.rows()[0]["status"], "Confirmed")  # invalid value ignored

    def test_search_and_filters(self):
        self.make_booking(full_name="Ananya Rao", phone="9876543210", service="full-bridal")
        self.make_booking(full_name="Zoya Khan", phone="9123456780", service="arabic", event_date=future(90))
        self.login()
        get = lambda q: self.client.get("/admin/?" + q).get_data(as_text=True)
        self.assertIn("Zoya Khan", get("q=zoya"))
        self.assertNotIn("Ananya Rao", get("q=zoya"))
        self.assertIn("Ananya Rao", get("q=98765"))
        self.assertNotIn("Zoya Khan", get("service=full-bridal"))
        self.assertIn("Zoya Khan", get("date_from=" + future(60)))
        self.assertNotIn("Ananya Rao", get("date_from=" + future(60)))
        self.assertNotIn("Zoya Khan", get("status=Confirmed"))
        self.assertIn("No bookings match", get("q=%25%27%3B+DROP+TABLE+bookings%3B--"))  # injection attempt
        self.assertEqual(len(self.rows()), 2)

    def test_delete_needs_post_and_login(self):
        booking = self.make_booking()
        self.login()
        self.assertEqual(self.client.get("/admin/booking/%d/delete" % booking["id"]).status_code, 405)
        self.assertEqual(len(self.rows()), 1)
        detail = self.client.get("/admin/booking/%d" % booking["id"]).get_data(as_text=True)
        self.assertIn("Yes, delete permanently", detail)  # confirmation panel is present
        self.client.post("/admin/booking/%d/delete" % booking["id"])
        self.assertEqual(self.rows(), [])


if __name__ == "__main__":
    unittest.main()
