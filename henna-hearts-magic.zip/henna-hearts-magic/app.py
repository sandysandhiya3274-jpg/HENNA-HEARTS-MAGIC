"""
app.py - creates and configures the Flask application.

Run locally:        python app.py
Run in production:  gunicorn "app:create_app()"
"""
import secrets
from datetime import datetime, timezone
from urllib.parse import urlparse

from flask import Flask, render_template, request
from werkzeug.exceptions import HTTPException

from config import Config
from data.site_data import SERVICES
from models import database
from routes.admin_routes import admin_bp
from routes.booking_routes import booking_bp
from routes.main_routes import main_bp
from utils import csrf


def inr(value):
    """Format a number as Indian rupees with lakh/crore grouping: 150000 -> Rs 1,50,000."""
    digits = str(int(value))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        digits = ",".join(groups + [tail])
    return "\u20b9" + digits


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    # ---- Secret key: mandatory in production, random (per-start) in development
    if not app.config.get("SECRET_KEY"):
        if app.config["APP_ENV"] == "production":
            raise RuntimeError("SECRET_KEY must be set in .env when APP_ENV=production")
        app.config["SECRET_KEY"] = secrets.token_hex(32)
        app.logger.warning("No SECRET_KEY set - using a temporary one (sessions reset on restart).")

    database.init_app(app)
    csrf.init_app(app)
    app.register_blueprint(main_bp)
    app.register_blueprint(booking_bp)
    app.register_blueprint(admin_bp)

    # ---- Template helpers --------------------------------------------------
    service_names = {s["id"]: s["name"] for s in SERVICES}
    service_names["advice"] = "Not sure yet - advise me"

    @app.context_processor
    def inject_globals():
        return {"business": app.config["BUSINESS"], "site_url": app.config["SITE_URL"],
                "year": datetime.now().year, "service_names": service_names}

    app.jinja_env.filters["inr"] = inr

    @app.template_filter("fmt_date")
    def fmt_date(value):
        try:
            return datetime.strptime(value, "%Y-%m-%d").strftime("%a, %d %b %Y")
        except (TypeError, ValueError):
            return value

    @app.template_filter("fmt_dt")
    def fmt_dt(value):
        """Stored timestamps are UTC; show them in the business timezone."""
        try:
            moment = datetime.strptime(value, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            try:
                from zoneinfo import ZoneInfo
                moment = moment.astimezone(ZoneInfo(app.config["TIMEZONE"]))
            except Exception:  # unknown timezone or missing tzdata: keep UTC
                pass
            return moment.strftime("%d %b %Y, %I:%M %p")
        except (TypeError, ValueError):
            return value

    @app.template_filter("pretty_phone")
    def pretty_phone(value):
        return "+91 %s %s" % (value[:5], value[5:]) if value and len(value) == 10 else value

    # ---- Security headers (added to every response) ------------------------
    map_host = ""
    if app.config["BUSINESS"]["map_embed_url"]:
        parsed = urlparse(app.config["BUSINESS"]["map_embed_url"])
        if parsed.scheme == "https" and parsed.netloc:
            map_host = "https://" + parsed.netloc

    csp = "; ".join([
        "default-src 'self'",
        "script-src 'self'",
        "style-src 'self' https://fonts.googleapis.com https://cdnjs.cloudflare.com",
        "font-src https://fonts.gstatic.com https://cdnjs.cloudflare.com",
        "img-src 'self' data: https:",
        "frame-src %s" % (map_host or "'none'"),
        "form-action 'self'",
        "base-uri 'self'",
        "frame-ancestors 'none'",
    ])

    @app.after_request
    def set_headers(response):
        response.headers["Content-Security-Policy"] = csp
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        if request.path.startswith("/admin") or request.path.startswith("/booking"):
            response.headers["Cache-Control"] = "no-store"  # don't cache private pages
        return response

    # ---- Friendly error pages ----------------------------------------------
    @app.errorhandler(404)
    def not_found(_error):
        return render_template("404.html"), 404

    @app.errorhandler(HTTPException)
    def http_error(error):
        return render_template("error.html", code=error.code, title=error.name,
                               message=error.description), error.code

    @app.errorhandler(Exception)
    def server_error(error):
        app.logger.exception("Unhandled error: %s", error)
        return render_template("error.html", code=500, title="Something went wrong",
                               message="An unexpected error occurred. Please try again in a moment."), 500

    return app


if __name__ == "__main__":
    # Local development server. For production use gunicorn (see README).
    create_app().run(debug=Config.APP_ENV != "production")
