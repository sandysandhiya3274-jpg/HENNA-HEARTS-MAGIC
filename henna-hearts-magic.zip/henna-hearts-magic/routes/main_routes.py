"""routes/main_routes.py - public pages: home, about, gallery, services, contact, style guide."""
from flask import (Blueprint, Response, current_app, flash, redirect, render_template,
                   request, url_for)

from data import recommend as rec
from data.site_data import (ARTIST_PROFILE, FAQS, GALLERY_CATEGORIES, GALLERY_ITEMS, PROMOTIONS,
                            SERVICES, TESTIMONIALS)
from models.database import create_enquiry
from utils.validators import validate_enquiry

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    featured_slugs = ("royal-bridal", "floral-arabic", "mughal-bel", "cuff-minimal")
    featured = [g for g in GALLERY_ITEMS if g["slug"] in featured_slugs]
    services = [s for s in SERVICES if s["id"] in ("full-bridal", "arabic", "custom-package")]
    return render_template("index.html", featured=featured, services=services,
                           testimonials=TESTIMONIALS, faqs=FAQS[:4], promotions=PROMOTIONS)


@main_bp.route("/about")
def about():
    return render_template("about.html", artist=ARTIST_PROFILE)


@main_bp.route("/gallery")
def gallery():
    return render_template("gallery.html", items=GALLERY_ITEMS, categories=GALLERY_CATEGORIES)


@main_bp.route("/services")
def services():
    return render_template("services.html", services=SERVICES, promotions=PROMOTIONS, faqs=FAQS)


@main_bp.route("/style-guide", methods=["GET", "POST"])
def style_guide():
    """Rule-based mehndi style recommendation (no external AI is used)."""
    result, answers = None, {}
    if request.method == "POST":
        answers = {q["name"]: request.form.get(q["name"], "") for q in rec.QUESTIONS}
        result = rec.recommend(answers)
        if result is None:
            flash("Please answer all four questions to get your recommendation.", "error")
        else:
            result["gallery_items"] = [g for g in GALLERY_ITEMS if g["category"] == result["top"]][:3]
            result["service"] = next((s for s in SERVICES if s["id"] == result["service_id"]), None)
    return render_template("recommend.html", questions=rec.QUESTIONS, answers=answers, result=result)


@main_bp.route("/contact", methods=["GET", "POST"])
def contact():
    form, errors = {}, {}
    if request.method == "POST":
        form = request.form.to_dict()
        if form.get("website"):  # hidden "honeypot" field: only bots fill it in
            return redirect(url_for("main.contact"))
        clean, errors = validate_enquiry(form)
        if not errors:
            try:
                create_enquiry(clean)
            except Exception:
                current_app.logger.exception("Could not save enquiry")
                flash("Sorry, we could not save your message. Please try WhatsApp or email instead.", "error")
            else:
                flash("Thank you! Your message has reached us and we will reply soon.", "success")
                return redirect(url_for("main.contact"))
        else:
            flash("Please fix the highlighted fields and send again.", "error")
        return render_template("contact.html", form=form, errors=errors), 400
    return render_template("contact.html", form=form, errors=errors)


@main_bp.route("/robots.txt")
def robots():
    body = "User-agent: *\nDisallow: /admin\nDisallow: /booking/confirmation/\nSitemap: %s/sitemap.xml\n" % current_app.config["SITE_URL"]
    return Response(body, mimetype="text/plain")


@main_bp.route("/sitemap.xml")
def sitemap():
    base = current_app.config["SITE_URL"]
    pages = ["main.index", "main.about", "main.gallery", "main.services", "main.style_guide",
             "booking.booking", "main.contact"]
    urls = "".join("<url><loc>%s%s</loc></url>" % (base, url_for(p)) for p in pages)
    xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">%s</urlset>' % urls
    return Response(xml, mimetype="application/xml")
