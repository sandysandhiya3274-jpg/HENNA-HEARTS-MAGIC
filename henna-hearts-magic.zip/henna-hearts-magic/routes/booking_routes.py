"""routes/booking_routes.py - the bridal booking form and confirmation page."""
from datetime import date

from flask import (Blueprint, abort, current_app, flash, redirect, render_template, request,
                   session, url_for)

from data.site_data import EVENT_TYPES, SERVICES, TIME_SLOTS
from models.database import create_booking, get_booking_by_reference
from utils.validators import SERVICE_IDS, validate_booking

booking_bp = Blueprint("booking", __name__)


def _render_form(form, errors, status=200):
    # Drop-down options as (value, label) pairs for the template
    return render_template(
        "booking.html", form=form, errors=errors, today=date.today().isoformat(),
        event_options=[(e, e) for e in EVENT_TYPES],
        time_options=[(t, t) for t in TIME_SLOTS],
        service_options=[(s["id"], s["name"]) for s in SERVICES] + [("advice", "Not sure yet - advise me")],
    ), status


@booking_bp.route("/booking", methods=["GET", "POST"])
def booking():
    form, errors = {}, {}

    if request.method == "POST":
        form = request.form.to_dict()
        if form.get("website"):  # honeypot field - real visitors never see or fill it
            return redirect(url_for("main.index"))

        clean, errors = validate_booking(form)
        if errors:
            flash("Please fix the highlighted fields and submit again.", "error")
            return _render_form(form, errors, 400)

        try:
            reference = create_booking(clean)  # saved to SQLite here
        except Exception:
            # Nothing was saved, so we must NOT tell the visitor it worked.
            current_app.logger.exception("Booking could not be saved")
            flash("We could not save your booking request. Nothing was submitted - please try again, "
                  "or contact us on WhatsApp.", "error")
            return _render_form(form, {}, 500)

        session["last_booking"] = reference  # lets this visitor (only) view the confirmation
        return redirect(url_for("booking.confirmation", reference=reference))

    # GET: pre-select a service when arriving from a "Book this" button (?service=arabic)
    service = request.args.get("service", "")
    if service in SERVICE_IDS:
        form["service"] = service
    return _render_form(form, errors)


@booking_bp.route("/booking/confirmation/<reference>")
def confirmation(reference):
    # Only the visitor who just submitted can see this page (it contains personal details).
    if session.get("last_booking") != reference:
        abort(404)
    booking_row = get_booking_by_reference(reference)
    if booking_row is None:
        abort(404)
    return render_template("confirmation.html", booking=booking_row)
