"""routes/admin_routes.py - login-protected dashboard for managing bookings."""
import time
from datetime import datetime
from functools import wraps

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from data.site_data import SERVICES
from models import database as db

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

# Used so that "unknown username" takes as long as "wrong password" (prevents user guessing).
_DUMMY_HASH = generate_password_hash("not-a-real-password")
# Failed login attempts per IP: {ip: [timestamps]}. In-memory, so per server process.
_failed_logins = {}
PER_PAGE = 15


# --------------------------------------------------------------------------
# Authentication helpers
# --------------------------------------------------------------------------
def login_required(view):
    """Decorator: only logged-in admins may open the page."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        admin_id = session.get("admin_id")
        admin = db.get_admin_by_id(admin_id) if admin_id else None
        if admin is None:  # not logged in, or the admin account was removed
            session.pop("admin_id", None)
            flash("Please sign in to continue.", "error")
            return redirect(url_for("admin.login"))
        g.admin = admin
        return view(*args, **kwargs)
    return wrapped


def _is_locked_out(ip):
    window = current_app.config["LOGIN_LOCKOUT_MINUTES"] * 60
    recent = [t for t in _failed_logins.get(ip, []) if time.time() - t < window]
    _failed_logins[ip] = recent
    return len(recent) >= current_app.config["LOGIN_MAX_ATTEMPTS"]


@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    if session.get("admin_id") and db.get_admin_by_id(session["admin_id"]):
        return redirect(url_for("admin.dashboard"))

    if request.method == "POST":
        ip = request.remote_addr or "unknown"
        if _is_locked_out(ip):
            flash("Too many failed attempts. Please wait %d minutes and try again."
                  % current_app.config["LOGIN_LOCKOUT_MINUTES"], "error")
            return render_template("login.html"), 429

        username = request.form.get("username", "").strip()[:80]
        password = request.form.get("password", "")[:200]
        admin = db.get_admin_by_username(username)
        valid = check_password_hash(admin["password_hash"] if admin else _DUMMY_HASH, password)

        if admin and valid:
            _failed_logins.pop(ip, None)
            session.clear()  # drop any old session data, then start a fresh one
            session["admin_id"] = admin["id"]
            session.permanent = True
            return redirect(url_for("admin.dashboard"))

        _failed_logins.setdefault(ip, []).append(time.time())
        flash("Incorrect username or password.", "error")
        return render_template("login.html"), 401
    return render_template("login.html")


@admin_bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been signed out.", "success")
    return redirect(url_for("admin.login"))


# --------------------------------------------------------------------------
# Dashboard and bookings
# --------------------------------------------------------------------------
def _valid_date(value):
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return value
    except ValueError:
        return ""


@admin_bp.route("/")
@login_required
def dashboard():
    filters = {
        "q": request.args.get("q", "").strip()[:80],
        "date_from": _valid_date(request.args.get("date_from", "")),
        "date_to": _valid_date(request.args.get("date_to", "")),
        "service": request.args.get("service", ""),
        "status": request.args.get("status", ""),
    }
    if filters["status"] not in db.STATUSES:
        filters["status"] = ""
    if filters["service"] not in {s["id"] for s in SERVICES} | {"advice"}:
        filters["service"] = ""
    page = max(request.args.get("page", 1, type=int), 1)

    rows, total = db.list_bookings(page=page, per_page=PER_PAGE, **filters)
    pages = max((total + PER_PAGE - 1) // PER_PAGE, 1)
    return render_template("admin_dashboard.html", bookings=rows, total=total, page=page, pages=pages,
                           filters=filters, stats=db.booking_stats(), statuses=db.STATUSES, services=SERVICES)


@admin_bp.route("/booking/<int:booking_id>")
@login_required
def booking_detail(booking_id):
    booking = db.get_booking(booking_id)
    if booking is None:
        abort(404)
    return render_template("admin_booking.html", booking=booking, statuses=db.STATUSES)


@admin_bp.route("/booking/<int:booking_id>/status", methods=["POST"])
@login_required
def update_status(booking_id):
    status = request.form.get("status", "")
    if status not in db.STATUSES:
        flash("That status is not allowed.", "error")
    elif db.update_booking_status(booking_id, status):
        flash("Status updated to %s." % status, "success")
    else:
        abort(404)
    return redirect(url_for("admin.booking_detail", booking_id=booking_id))


@admin_bp.route("/booking/<int:booking_id>/delete", methods=["POST"])
@login_required
def delete_booking(booking_id):
    # The detail page only shows this button inside a "Are you sure?" confirmation panel.
    if not db.delete_booking(booking_id):
        abort(404)
    flash("Booking deleted permanently.", "success")
    return redirect(url_for("admin.dashboard"))


# --------------------------------------------------------------------------
# Contact enquiries
# --------------------------------------------------------------------------
@admin_bp.route("/enquiries")
@login_required
def enquiries():
    return render_template("admin_enquiries.html", enquiries=db.list_enquiries(), stats=db.booking_stats())


@admin_bp.route("/enquiries/<int:enquiry_id>/read", methods=["POST"])
@login_required
def enquiry_read(enquiry_id):
    db.mark_enquiry_read(enquiry_id)
    return redirect(url_for("admin.enquiries"))
