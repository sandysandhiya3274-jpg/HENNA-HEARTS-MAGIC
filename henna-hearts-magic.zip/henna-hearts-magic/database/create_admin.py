"""
database/create_admin.py - creates an admin account safely.

Usage:   python database/create_admin.py
The password is typed at a hidden prompt, so it never appears in files, shell
history or source code. It is stored only as a salted hash.
"""
import getpass
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import create_app  # noqa: E402
from models import database  # noqa: E402

MIN_PASSWORD_LENGTH = 12


def main():
    app = create_app()
    database.init_schema(app.config["DATABASE_PATH"])  # make sure tables exist

    username = input("Choose an admin username: ").strip()
    if len(username) < 3:
        sys.exit("Username must be at least 3 characters.")

    password = getpass.getpass("Choose a password (min %d characters): " % MIN_PASSWORD_LENGTH)
    if len(password) < MIN_PASSWORD_LENGTH:
        sys.exit("Password must be at least %d characters long." % MIN_PASSWORD_LENGTH)
    if password != getpass.getpass("Repeat the password: "):
        sys.exit("Passwords did not match. Nothing was created.")

    with app.app_context():
        try:
            database.create_admin(username, password)
        except sqlite3.IntegrityError:
            sys.exit("An admin named '%s' already exists." % username)
    print("Admin '%s' created. Sign in at /admin/login" % username)


if __name__ == "__main__":
    main()
