"""
database/init_db.py - creates the SQLite database and tables.

Usage (from the project folder):   python database/init_db.py
Safe to run more than once - existing data is kept.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))  # so "import config" works

from config import Config  # noqa: E402
from models.database import init_schema  # noqa: E402

if __name__ == "__main__":
    init_schema(Config.DATABASE_PATH)
    print("Database ready at:", Config.DATABASE_PATH)
