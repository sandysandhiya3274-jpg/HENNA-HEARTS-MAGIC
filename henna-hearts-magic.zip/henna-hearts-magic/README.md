# Henna Hearts Magic
**Luxury Mehndi Website for Bridal Booking and Client Attraction**

A Flask + SQLite website for a bridal mehndi artist: public pages, a bridal booking form that saves to a database,
a contact form, a rule-based style guide, and a password-protected admin dashboard.

> **Sample content:** prices, testimonials, the artist profile, offers and contact details are demo content.
> Replace them before going live (see "Customising content").

## Pages and features
| Area | What it does |
|---|---|
| Home, About, Gallery, Services | Luxury design, category-filtered gallery, ₹ sample pricing, FAQ, promotions |
| Booking (`/booking`) | Validated form, past dates blocked, unique reference (e.g. `HHM-261023-K7X2Q`), confirmation page. Status starts as **Pending** and is only shown after the database save succeeds |
| Contact (`/contact`) | WhatsApp, email, Instagram links, enquiry form saved to the database, hours, map placeholder |
| Style guide (`/style-guide`) | **Rule-based** recommendation that runs locally. No external AI is connected and no API key is used |
| Admin (`/admin`) | Login/logout, stats, search (name/phone/reference), filters (date/service/status), detail view, status updates, delete behind an "Are you sure?" panel, enquiries inbox |

Not included on purpose: a newsletter sign-up. The brief said to add it only if it can be done properly, and that needs an
email-sending service and a double opt-in process that this project doesn't have.

## 1. Prerequisites
- Python 3.9 or newer (`python --version`). Download from python.org if needed.
- A terminal (Command Prompt/PowerShell on Windows, Terminal on macOS/Linux).
- Internet access when viewing the site (Google Fonts and Font Awesome icons load from CDNs).

## 2. Create a virtual environment
```bash
cd henna-hearts-magic
python -m venv venv
# Windows (PowerShell):  venv\Scripts\Activate.ps1
# Windows (cmd):         venv\Scripts\activate.bat
# macOS / Linux:         source venv/bin/activate
```

## 3. Install dependencies
```bash
pip install -r requirements.txt
```
(`gunicorn` is only used on Linux/macOS hosting. If it fails to install on Windows, remove that line for local use.)

## 4. Configure environment variables
```bash
cp .env.example .env        # Windows: copy .env.example .env
```
Edit `.env`:
- `SECRET_KEY` - generate one with `python -c "import secrets; print(secrets.token_hex(32))"`
- Business details: `BUSINESS_NAME`, `WHATSAPP_NUMBER` (digits with country code, e.g. `919876543210`), `BUSINESS_EMAIL`,
  `INSTAGRAM_URL`, `BUSINESS_ADDRESS`, `OPENING_HOURS`, optional `MAP_EMBED_URL`.

Never commit `.env` (it is already in `.gitignore`).

## 5. Initialise the database
```bash
python database/init_db.py
```
Creates `database/henna_hearts.db` with the tables `admin_users`, `bookings` and `contact_enquiries`. Safe to re-run.

## 6. Create the first admin account securely
```bash
python database/create_admin.py
```
You choose the username and type the password at a hidden prompt (minimum 12 characters). Only a salted hash is stored.
There is no default admin account and no password in the source code.

## 7. Run the website locally
```bash
python app.py
```
Open http://127.0.0.1:5000

## 8. Open the admin dashboard
Go to http://127.0.0.1:5000/admin/login and sign in. (A small "Admin" link is also in the footer.)

## 9. Run the tests
```bash
python -m unittest discover -s tests -v
```
(`pytest` also works if installed.) Tests use a temporary database, so your real data is untouched.
They cover validation, past-date blocking, saving, unique references, CSRF, login protection, password hashing,
search/filters, status updates and deletion.

## 10. Deploy to production
These steps are the recommended approach; they were not run against a live server as part of this project.

1. **Server:** any Linux VPS or a Python host (Render, Railway, PythonAnywhere, etc.). Copy the project (not `.env` or `*.db`).
2. **Environment:** set `APP_ENV=production`, a strong `SECRET_KEY` (the app refuses to start in production without one),
   `SITE_URL=https://your-domain`, and your business details. Secure cookies are enabled automatically.
3. **HTTPS is required.** Put the app behind Nginx/Caddy or the host's HTTPS proxy with a free Let's Encrypt certificate.
4. **Run with Gunicorn**, not `python app.py`:
   ```bash
   pip install -r requirements.txt
   python database/init_db.py
   python database/create_admin.py
   gunicorn --workers 2 --bind 127.0.0.1:8000 "app:create_app()"
   ```
   Keep it running with systemd or your host's process manager.
5. **SQLite on the host:** store `DATABASE_PATH` on persistent disk (some hosts wipe the filesystem on every deploy)
   and **back up the `.db` file regularly** - it holds customer details.
6. **Hardening to consider:** add rate limiting (e.g. Flask-Limiter or at Nginx) - the built-in login lockout is
   per-process memory only; set up email notifications for new bookings; review privacy/data-retention rules for
   customer details you store.

## Customising content
- **Prices, services, gallery, testimonials, FAQ, offers, artist bio:** edit `data/site_data.py`.
- **Real photos:** drop files into `static/images/` and set each gallery item's `image` (see `static/images/README.md`).
  Items with no photo show built-in sample artwork, clearly labelled "Sample artwork".
- **Genuine reviews:** add entries to `TESTIMONIALS` with `"is_demo": False`, and delete the demo ones.
- **Colours and fonts:** the variables at the top of `static/css/style.css`.

## Project structure
```
henna-hearts-magic/
├── app.py                  # creates the Flask app, security headers, error pages
├── config.py               # settings read from .env
├── requirements.txt  .env.example  .gitignore  README.md
├── database/   init_db.py  create_admin.py
├── models/     database.py            # all SQL (parameterised queries)
├── routes/     main_routes.py  booking_routes.py  admin_routes.py
├── utils/      validators.py  csrf.py
├── data/       site_data.py  recommend.py   # editable content + style-guide rules
├── templates/  base, admin_base, index, about, gallery, services, recommend, booking,
│               confirmation, contact, login, admin_dashboard, admin_booking,
│               admin_enquiries, 404, error, _macros, _vine
├── static/     css/style.css  js/main.js  images/
└── tests/      test_bookings.py
```

## Security notes
CSRF token on every POST form · salted password hashing (Werkzeug) · HttpOnly/SameSite/Secure session cookies, 2-hour
admin sessions · login lockout (5 failures / 15 min per IP) · parameterised SQL only · automatic HTML escaping ·
strict Content-Security-Policy (no inline scripts) · honeypot field against spam bots · confirmation page visible only
to the visitor who submitted · admin pages sent with `no-store`. Stored customer data is limited to what is needed to
fulfil a booking.

## Verification checklist
- [ ] `python database/init_db.py` prints "Database ready"
- [ ] `python database/create_admin.py` creates your admin
- [ ] `python -m unittest discover -s tests` ends with `OK`
- [ ] Home page loads; the hero vine draws itself; both hero buttons work
- [ ] Gallery filter buttons show/hide the right designs
- [ ] Booking: a past date is rejected; a bad email/phone is rejected; a valid request shows a reference
- [ ] The new booking appears in `/admin` as **Pending**; changing status to Confirmed works
- [ ] Deleting a booking requires opening the "Delete this booking" panel and confirming
- [ ] Visiting `/admin/` while signed out redirects to the login page
- [ ] Contact form message appears under Admin → Enquiries
- [ ] WhatsApp buttons open a chat with the number in `.env`
- [ ] Site looks right at phone width (menu button opens the navigation)
- [ ] Sample prices, testimonials and profile replaced before launch
