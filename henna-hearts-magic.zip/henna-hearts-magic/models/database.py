"""
models/database.py - everything that talks to the SQLite database.

All queries use "?" placeholders (parameterised queries), which makes SQL
injection impossible. Never build SQL by joining user text into a string.
"""
import secrets
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from flask import current_app, g
from werkzeug.security import generate_password_hash

STATUSES = ("Pending", "Confirmed", "Completed", "Cancelled")

SCHEMA = """
CREATE TABLE IF NOT EXISTS admin_users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,              -- salted hash, never the real password
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    reference      TEXT NOT NULL UNIQUE,      -- e.g. HHM-261023-K7X2Q
    full_name      TEXT NOT NULL,
    email          TEXT NOT NULL,
    phone          TEXT NOT NULL,             -- 10-digit Indian mobile number
    event_type     TEXT NOT NULL,
    event_date     TEXT NOT NULL,             -- YYYY-MM-DD
    preferred_time TEXT NOT NULL,
    location       TEXT NOT NULL,
    guest_count    INTEGER NOT NULL CHECK (guest_count BETWEEN 1 AND 500),
    service        TEXT NOT NULL,
    notes          TEXT NOT NULL DEFAULT '',
    status         TEXT NOT NULL DEFAULT 'Pending'
                   CHECK (status IN ('Pending','Confirmed','Completed','Cancelled')),
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bookings_event_date ON bookings (event_date);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings (status);

CREATE TABLE IF NOT EXISTS contact_enquiries (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    email      TEXT NOT NULL,
    phone      TEXT NOT NULL DEFAULT '',
    message    TEXT NOT NULL,
    is_read    INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
);
"""

# Letters/numbers without look-alikes (no 0/O or 1/I) so references are easy to read aloud.
_REF_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


def _now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# --------------------------------------------------------------------------
# Connection handling
# --------------------------------------------------------------------------
def get_db():
    """One connection per request, reused until the request ends."""
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE_PATH"])
        g.db.row_factory = sqlite3.Row  # lets us read columns by name
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_schema(db_path):
    """Create the database file and all tables (safe to run repeatedly)."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


def init_app(app):
    app.teardown_appcontext(close_db)


# --------------------------------------------------------------------------
# Admin users
# --------------------------------------------------------------------------
def create_admin(username, password):
    """Store a new admin with a securely hashed password (pbkdf2/scrypt via Werkzeug)."""
    db = get_db()
    db.execute(
        "INSERT INTO admin_users (username, password_hash, created_at) VALUES (?, ?, ?)",
        (username, generate_password_hash(password), _now()),
    )
    db.commit()


def get_admin_by_username(username):
    return get_db().execute("SELECT * FROM admin_users WHERE username = ?", (username,)).fetchone()


def get_admin_by_id(admin_id):
    return get_db().execute("SELECT * FROM admin_users WHERE id = ?", (admin_id,)).fetchone()


# --------------------------------------------------------------------------
# Bookings
# --------------------------------------------------------------------------
def _new_reference():
    stamp = datetime.now(timezone.utc).strftime("%y%m%d")
    return "HHM-%s-%s" % (stamp, "".join(secrets.choice(_REF_ALPHABET) for _ in range(5)))


def create_booking(data):
    """
    Save a validated booking and return its unique reference.
    Raises an exception if saving fails - callers must NOT show success in that case.
    """
    db = get_db()
    for _ in range(10):  # retry in the (very unlikely) event of a duplicate reference
        reference = _new_reference()
        now = _now()
        try:
            db.execute(
                """INSERT INTO bookings
                   (reference, full_name, email, phone, event_type, event_date, preferred_time,
                    location, guest_count, service, notes, status, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?)""",
                (reference, data["full_name"], data["email"], data["phone"], data["event_type"],
                 data["event_date"], data["preferred_time"], data["location"], data["guest_count"],
                 data["service"], data["notes"], now, now),
            )
            db.commit()
            return reference
        except sqlite3.IntegrityError as exc:
            db.rollback()
            if "bookings.reference" not in str(exc):
                raise
    raise RuntimeError("Could not generate a unique booking reference")


def get_booking(booking_id):
    return get_db().execute("SELECT * FROM bookings WHERE id = ?", (booking_id,)).fetchone()


def get_booking_by_reference(reference):
    return get_db().execute("SELECT * FROM bookings WHERE reference = ?", (reference,)).fetchone()


def _like(term):
    """Escape % and _ so they are searched literally, then wrap for LIKE."""
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return "%" + escaped + "%"


def list_bookings(q="", date_from="", date_to="", service="", status="", page=1, per_page=15):
    """Return (rows, total_matching) for the admin table, with optional filters."""
    where, params = [], []
    if q:
        digits = "".join(ch for ch in q if ch.isdigit())
        clause = "full_name LIKE ? ESCAPE '\\' OR reference LIKE ? ESCAPE '\\'"
        params += [_like(q), _like(q)]
        if digits:
            clause += " OR phone LIKE ? ESCAPE '\\'"
            params.append(_like(digits))
        where.append("(" + clause + ")")
    if date_from:
        where.append("event_date >= ?")
        params.append(date_from)
    if date_to:
        where.append("event_date <= ?")
        params.append(date_to)
    if service:
        where.append("service = ?")
        params.append(service)
    if status:
        where.append("status = ?")
        params.append(status)
    clause = (" WHERE " + " AND ".join(where)) if where else ""

    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM bookings" + clause, params).fetchone()[0]
    rows = db.execute(
        "SELECT * FROM bookings" + clause + " ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
        params + [per_page, (page - 1) * per_page],
    ).fetchall()
    return rows, total


def update_booking_status(booking_id, status):
    if status not in STATUSES:
        raise ValueError("Invalid status")
    db = get_db()
    cur = db.execute("UPDATE bookings SET status = ?, updated_at = ? WHERE id = ?", (status, _now(), booking_id))
    db.commit()
    return cur.rowcount == 1


def delete_booking(booking_id):
    db = get_db()
    cur = db.execute("DELETE FROM bookings WHERE id = ?", (booking_id,))
    db.commit()
    return cur.rowcount == 1


def booking_stats():
    """Numbers shown on the dashboard cards."""
    db = get_db()
    stats = {"total": db.execute("SELECT COUNT(*) FROM bookings").fetchone()[0]}
    for status in STATUSES:
        stats[status.lower()] = db.execute("SELECT COUNT(*) FROM bookings WHERE status = ?", (status,)).fetchone()[0]
    stats["unread_enquiries"] = db.execute("SELECT COUNT(*) FROM contact_enquiries WHERE is_read = 0").fetchone()[0]
    return stats


# --------------------------------------------------------------------------
# Contact enquiries
# --------------------------------------------------------------------------
def create_enquiry(data):
    db = get_db()
    db.execute(
        "INSERT INTO contact_enquiries (name, email, phone, message, created_at) VALUES (?, ?, ?, ?, ?)",
        (data["name"], data["email"], data["phone"], data["message"], _now()),
    )
    db.commit()


def list_enquiries():
    return get_db().execute("SELECT * FROM contact_enquiries ORDER BY is_read ASC, created_at DESC, id DESC").fetchall()


def mark_enquiry_read(enquiry_id):
    db = get_db()
    db.execute("UPDATE contact_enquiries SET is_read = 1 WHERE id = ?", (enquiry_id,))
    db.commit()
