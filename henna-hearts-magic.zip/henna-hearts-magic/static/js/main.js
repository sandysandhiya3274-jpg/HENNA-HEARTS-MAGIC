/* ==========================================================================
   main.js - small, dependency-free interactions for Henna Hearts Magic.
   (No inline scripts are used anywhere, so the strict Content-Security-Policy
   in app.py can stay switched on.)
   ========================================================================== */
(function () {
  "use strict";

  /* ---- 1. Mobile navigation toggle ------------------------------------- */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("site-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", String(open));
    });
  }

  /* ---- 2. Sample artwork generator -------------------------------------
     When a gallery item has no photo (or the photo fails to load) we draw a
     henna-style mandala in SVG. The "seed" (the item's slug) makes every
     tile different but always the same on each visit.                      */
  function seededRandom(seed) {
    var h = 2166136261;
    for (var i = 0; i < seed.length; i++) { h ^= seed.charCodeAt(i); h = Math.imul(h, 16777619); }
    return function () {
      h += 0x6d2b79f5;
      var t = Math.imul(h ^ (h >>> 15), 1 | h);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  var PALETTES = {
    emerald: { bg1: "#14604d", bg2: "#082f25", ink: "#e4cc8a" },
    maroon:  { bg1: "#7a1a35", bg2: "#3b0b19", ink: "#efd9a0" },
    gold:    { bg1: "#8a6a26", bg2: "#4d3a12", ink: "#fbf0cf" }
  };

  function buildArt(seed, paletteName) {
    var rnd = seededRandom(seed);
    var p = PALETTES[paletteName] || PALETTES.emerald;
    var cx = 100, cy = 118, parts = [];
    parts.push('<defs><radialGradient id="g-' + seed + '" cx="50%" cy="46%" r="75%">' +
      '<stop offset="0" stop-color="' + p.bg1 + '"/><stop offset="1" stop-color="' + p.bg2 + '"/></radialGradient></defs>');
    parts.push('<rect width="200" height="250" fill="url(#g-' + seed + ')"/>');
    parts.push('<rect x="8" y="8" width="184" height="234" rx="10" fill="none" stroke="' + p.ink + '" stroke-opacity=".55" stroke-width="1"/>');
    parts.push('<rect x="13" y="13" width="174" height="224" rx="7" fill="none" stroke="' + p.ink + '" stroke-opacity=".3" stroke-width=".7"/>');

    // Concentric rings of petals and dots
    var radius = 12, rings = 4;
    for (var r = 0; r < rings; r++) {
      var count = 6 + Math.floor(rnd() * 7);
      var len = 11 + rnd() * 9, wide = 4 + rnd() * 5;
      if (radius + len > 76) { break; }  // keep every ring inside the frame
      var petal = "M0 0 C" + wide + " " + (-len * 0.4) + "," + wide + " " + (-len * 0.8) + ",0 " + (-len) +
                  " C" + (-wide) + " " + (-len * 0.8) + "," + (-wide) + " " + (-len * 0.4) + ",0 0Z";
      for (var i = 0; i < count; i++) {
        var angle = (360 / count) * i + (r % 2 ? 180 / count : 0);
        parts.push('<path d="' + petal + '" transform="translate(' + cx + ' ' + cy + ') rotate(' + angle.toFixed(1) +
          ') translate(0 ' + (-radius).toFixed(1) + ')" fill="' + (rnd() > 0.7 ? p.ink : "none") +
          '" fill-opacity=".25" stroke="' + p.ink + '" stroke-width="1" stroke-linejoin="round"/>');
        var dotAngle = ((360 / count) * (i + 0.5) + (r % 2 ? 180 / count : 0)) * Math.PI / 180;
        var dr = radius + len + 3;
        parts.push('<circle cx="' + (cx + Math.sin(dotAngle) * dr).toFixed(1) + '" cy="' + (cy - Math.cos(dotAngle) * dr).toFixed(1) +
          '" r="1.4" fill="' + p.ink + '"/>');
      }
      radius += len + 6;
    }
    parts.push('<circle cx="' + cx + '" cy="' + cy + '" r="6" fill="' + p.ink + '"/>');

    // A vine along the bottom with little leaves
    var vine = "M20 226 C50 206 70 246 100 226 S150 206 180 226";
    parts.push('<path d="' + vine + '" fill="none" stroke="' + p.ink + '" stroke-width="1.4" stroke-linecap="round"/>');
    [40, 70, 100, 130, 160].forEach(function (x, idx) {
      var up = idx % 2 === 0;
      parts.push('<path d="M' + x + ' 226 q6 ' + (up ? -9 : 9) + ' 13 ' + (up ? -3 : 3) + ' q-6 ' + (up ? 7 : -7) + ' -13 ' + (up ? 3 : -3) +
        '" fill="' + p.ink + '" fill-opacity=".35" stroke="' + p.ink + '" stroke-width=".8"/>');
    });
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 250" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">' +
           parts.join("") + "</svg>";
  }

  function renderArt(box) {
    box.innerHTML = buildArt(box.dataset.seed || "henna", box.dataset.palette);
  }

  // Draw artwork for every tile that has no photo
  document.querySelectorAll(".art").forEach(function (box) {
    if (!box.querySelector("img")) { renderArt(box); }
  });

  // If a photo fails to load, swap it for the sample artwork (error events don't bubble, so we capture)
  function fallbackFor(img) {
    var box = img.closest(".art");
    if (!box) { return; }
    box.setAttribute("role", "img");
    box.setAttribute("aria-label", img.alt + " (photo unavailable - sample artwork shown)");
    renderArt(box);
    var card = box.parentElement;
    if (card && !card.querySelector(".sample-tag")) {
      var tag = document.createElement("span");
      tag.className = "sample-tag";
      tag.textContent = "Sample artwork";
      card.insertBefore(tag, card.firstChild);
    }
  }
  document.addEventListener("error", function (event) {
    if (event.target && event.target.tagName === "IMG" && event.target.hasAttribute("data-fallback")) {
      fallbackFor(event.target);
    }
  }, true);
  document.querySelectorAll("img[data-fallback]").forEach(function (img) {
    if (img.complete && img.naturalWidth === 0) { fallbackFor(img); } // failed before this script ran
  });

  /* ---- 3. Hero vine: stagger the drawing of each stroke ------------------ */
  document.querySelectorAll(".vine path").forEach(function (path, index) {
    path.style.animationDelay = (index * 0.14).toFixed(2) + "s";
  });

  /* ---- 4. Gallery filter ------------------------------------------------- */
  var filterButtons = document.querySelectorAll(".filter-btn");
  var items = document.querySelectorAll(".gallery-item");
  filterButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      var wanted = button.dataset.filter;
      filterButtons.forEach(function (b) { b.setAttribute("aria-pressed", String(b === button)); });
      items.forEach(function (item) {
        item.hidden = !(wanted === "all" || item.dataset.category === wanted);
      });
      var status = document.getElementById("filter-status");
      if (status) {
        status.textContent = document.querySelectorAll(".gallery-item:not([hidden])").length + " designs shown";
      }
    });
  });

  /* ---- 5. Booking form helpers ---------------------------------------------
     The server re-checks everything; these only make the form friendlier.     */
  var dateInput = document.getElementById("event_date");
  if (dateInput && !dateInput.min) {
    var now = new Date();
    var pad = function (n) { return String(n).padStart(2, "0"); };
    dateInput.min = now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate());
  }
  var bookingForm = document.getElementById("booking-form");
  if (bookingForm) {
    bookingForm.addEventListener("submit", function () {
      var button = bookingForm.querySelector("button[type=submit]");
      if (button) { button.disabled = true; button.textContent = "Sending your request..."; }
    });
    // If the form is shown again with errors, bring the summary into view.
    var summary = document.querySelector(".error-summary");
    if (summary) { summary.focus(); }
  }

  /* ---- 6. Print button on the confirmation page ---------------------------- */
  document.querySelectorAll("[data-print]").forEach(function (button) {
    button.addEventListener("click", function () { window.print(); });
  });
})();
