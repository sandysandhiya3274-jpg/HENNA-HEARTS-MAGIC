# Images folder

Put your own portfolio photos here (JPG/WebP, about 800x1000 pixels, under 300 KB each for fast loading).

Then open `data/site_data.py`, find the gallery item, and set its file name:

    {"slug": "royal-bridal", ..., "image": "bridal-1.jpg", ...}

You can also paste a full `https://...` image address you have the right to use.
Only use photos you own or are licensed to use, and ask clients for permission before showing their hands.

If an image is missing or fails to load, the site automatically shows built-in sample artwork instead.
