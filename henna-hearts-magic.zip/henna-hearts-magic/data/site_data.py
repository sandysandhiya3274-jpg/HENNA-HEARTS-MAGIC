"""
data/site_data.py - the editable CONTENT of the website.

Business owners: change the text, prices and images here - no HTML knowledge needed.

IMPORTANT NOTES
* Prices are ILLUSTRATIVE samples. Replace them with your real prices.
* Testimonials, the artist profile and the FAQ answers are SAMPLE content.
* Gallery images: each item has an "image" field. Leave it empty ("") and the site
  shows built-in sample artwork. To use real photos, either
    - paste a full https:// image URL you have the right to use, or
    - save the photo in static/images/ and write its file name, e.g. "bridal-1.jpg".
  If a photo fails to load, the sample artwork is shown instead - the page never breaks.
"""

EVENT_TYPES = ["Wedding", "Engagement", "Reception", "Sangeet / Mehndi Night", "Festival", "Other"]

TIME_SLOTS = [
    "Early morning (6 AM - 9 AM)",
    "Morning (9 AM - 12 PM)",
    "Afternoon (12 PM - 4 PM)",
    "Evening (4 PM - 8 PM)",
    "Flexible - discuss with artist",
]

# ---- Services & packages (prices are illustrative samples) ------------------
SERVICES = [
    {
        "id": "full-bridal", "icon": "fa-crown", "name": "Full Bridal Mehndi", "price": 9999,
        "price_note": "per bride, hands & feet",
        "desc": "Elbow-deep hands and feet with intricate motifs, storytelling elements and a hidden message for the groom.",
        "includes": ["Both hands to elbow, both feet to ankle", "Bride & groom story details", "Natural henna paste", "Aftercare guidance"],
        "duration": "5-6 hours", "popular": True,
    },
    {
        "id": "engagement", "icon": "fa-ring", "name": "Engagement Mehndi", "price": 3499,
        "price_note": "per person, both hands",
        "desc": "Delicate and romantic designs that frame the ring perfectly - ideal for the big question's celebration.",
        "includes": ["Both hands to wrist or mid-forearm", "Ring-finger focus motif", "Natural henna paste"],
        "duration": "2 hours", "popular": False,
    },
    {
        "id": "reception", "icon": "fa-champagne-glasses", "name": "Reception Mehndi", "price": 4999,
        "price_note": "per person",
        "desc": "Modern, elegant designs made to complement your reception outfit and jewellery.",
        "includes": ["Hands to mid-forearm", "Contemporary or fusion styling", "Natural henna paste"],
        "duration": "2.5 hours", "popular": False,
    },
    {
        "id": "arabic", "icon": "fa-leaf", "name": "Arabic Mehndi", "price": 1999,
        "price_note": "per person, one side",
        "desc": "Flowing vines, bold florals and open spaces for a graceful, contemporary look.",
        "includes": ["Back of both hands", "Choice of floral or vine style", "Natural henna paste"],
        "duration": "1 hour", "popular": True,
    },
    {
        "id": "guest-family", "icon": "fa-people-group", "name": "Guest & Family Mehndi", "price": 499,
        "price_note": "per person, starting from",
        "desc": "Quick, beautiful designs for the bride's family and guests. Perfect for mehndi nights and sangeets.",
        "includes": ["Simple to medium designs", "Group-friendly pricing", "Natural henna paste"],
        "duration": "15-45 min per person", "popular": False,
    },
    {
        "id": "custom-package", "icon": "fa-gem", "name": "Customized Bridal Package", "price": 19999,
        "price_note": "starting from, tailored to you",
        "desc": "A complete wedding-week plan: bridal mehndi, engagement or sangeet looks and family sessions - designed together.",
        "includes": ["Full bridal mehndi", "Up to 5 family/guest designs", "Pre-wedding design consultation", "Priority date reservation"],
        "duration": "Planned with you", "popular": False,
    },
]

PROMOTIONS = [
    {"title": "Early-bird bridal offer", "text": "Book your full bridal mehndi 90+ days ahead and receive Rs. 1,000 off. (Sample offer - edit before launch.)"},
    {"title": "Bridal party bundle", "text": "Book bridal mehndi with 5 or more guest designs and enjoy a complimentary mini-design for the bride's mother. (Sample offer.)"},
]

# ---- Gallery -------------------------------------------------------------
GALLERY_CATEGORIES = [
    {"slug": "bridal", "label": "Bridal"},
    {"slug": "arabic", "label": "Arabic"},
    {"slug": "traditional", "label": "Traditional Indian"},
    {"slug": "minimal", "label": "Minimal & Engagement"},
]

# "palette" only affects the built-in sample artwork: emerald, maroon or gold.
GALLERY_ITEMS = [
    {"slug": "royal-bridal", "category": "bridal", "title": "Royal Full-Hand Bridal", "image": "", "palette": "maroon",
     "alt": "Bridal mehndi covering both hands with dense paisley and floral motifs"},
    {"slug": "peacock-bridal", "category": "bridal", "title": "Peacock Motif Bridal", "image": "", "palette": "emerald",
     "alt": "Bridal henna design featuring a peacock motif across the palm"},
    {"slug": "dulhan-story", "category": "bridal", "title": "Dulhan Story Palms", "image": "", "palette": "gold",
     "alt": "Bridal palms with a wedding procession scene drawn in henna"},
    {"slug": "floral-arabic", "category": "arabic", "title": "Floral Arabic Vine", "image": "", "palette": "emerald",
     "alt": "Arabic mehndi with a flowing floral vine along the hand and wrist"},
    {"slug": "bold-arabic", "category": "arabic", "title": "Bold Arabic Trail", "image": "", "palette": "maroon",
     "alt": "Bold Arabic henna trail with large leaves and open spaces"},
    {"slug": "arabic-bloom", "category": "arabic", "title": "Arabic Wrist Bloom", "image": "", "palette": "gold",
     "alt": "Arabic henna design with a blooming flower at the wrist"},
    {"slug": "jaali-trad", "category": "traditional", "title": "Rajasthani Jaali", "image": "", "palette": "gold",
     "alt": "Traditional Rajasthani mehndi with fine lattice jaali work"},
    {"slug": "mughal-bel", "category": "traditional", "title": "Mughal Paisley Bel", "image": "", "palette": "maroon",
     "alt": "Traditional mehndi inspired by Mughal paisley creeper patterns"},
    {"slug": "mandala-palm", "category": "traditional", "title": "Mandala Palm", "image": "", "palette": "emerald",
     "alt": "Traditional palm mehndi with a central mandala and surrounding motifs"},
    {"slug": "cuff-minimal", "category": "minimal", "title": "Minimal Engagement Cuff", "image": "", "palette": "emerald",
     "alt": "Minimal engagement mehndi shaped like a delicate cuff around the wrist"},
    {"slug": "ring-motif", "category": "minimal", "title": "Ring Finger Motif", "image": "", "palette": "gold",
     "alt": "Minimal henna design highlighting the ring finger for an engagement"},
    {"slug": "fingertip-sangeet", "category": "minimal", "title": "Sangeet Fingertips", "image": "", "palette": "maroon",
     "alt": "Light henna on fingertips with a small flower on the back of the hand"},
]

# ---- Testimonials (SAMPLE / DEMO content) ----------------------------------
# To add genuine reviews later: add a new dict with "is_demo": False (or delete the demo ones).
TESTIMONIALS = [
    {"name": "Ananya R.", "event": "Wedding", "rating": 5, "is_demo": True,
     "text": "The design told our whole story, down to the tiny initials hidden in the pattern. The stain came out deep and rich."},
    {"name": "Fathima S.", "event": "Engagement", "rating": 5, "is_demo": True,
     "text": "Calm, punctual and so talented. The ring-finger motif was exactly the delicate look I had imagined."},
    {"name": "Priya & family", "event": "Mehndi night", "rating": 5, "is_demo": True,
     "text": "She handled twenty guests without any chaos, and everyone left happy. Booking was simple and clear."},
]

# ---- FAQ (sample answers - edit to match your policies) ----------------------
FAQS = [
    {"q": "How far in advance should I book my bridal mehndi?",
     "a": "We recommend booking 2-3 months ahead for wedding season (October-March). Last-minute requests are welcome and depend on availability."},
    {"q": "Is my booking confirmed as soon as I submit the form?",
     "a": "No. Submitting the form sends us a booking request and gives you a reference number. Your date is confirmed only after the artist checks availability and contacts you."},
    {"q": "Do you travel to the venue?",
     "a": "Yes, we can travel for events. Travel charges depend on distance and are shared before you confirm."},
    {"q": "Is the henna natural?",
     "a": "We use natural henna paste. Please tell us about any skin allergies or sensitivities when you book, and never use 'black henna'."},
    {"q": "How long does bridal mehndi take?",
     "a": "Full bridal mehndi usually takes 5-6 hours. Engagement and guest designs are much quicker. Your artist will give a timing estimate."},
    {"q": "How do I make the stain darker?",
     "a": "Keep the paste on for as long as comfortable, dab on a lemon-sugar mix, and avoid water for the first hours. We share full aftercare tips with every booking."},
    {"q": "What if I need to change my date?",
     "a": "Message us on WhatsApp or email with your booking reference as early as possible and we will do our best to adjust."},
]

ARTIST_PROFILE = {
    "title": "Bridal Mehndi Artist & Founder",
    "bio": ("Henna has been part of every celebration in our family for generations. What began as drawing "
            "designs for cousins before their weddings grew into a studio devoted to bridal artistry."),
    "style": "Fine-line traditional work blended with flowing Arabic vines, with personal story details in every design.",
    "pillars": [
        {"icon": "fa-feather-pointed", "title": "Hand-drawn, never traced", "text": "Every design is drawn freehand and fitted to your hands, outfit and story."},
        {"icon": "fa-leaf", "title": "Natural henna", "text": "Fresh, natural paste for a rich stain and gentle care for your skin."},
        {"icon": "fa-clock", "title": "On time, unhurried", "text": "We plan the schedule around your ceremony so you can relax."},
    ],
}
