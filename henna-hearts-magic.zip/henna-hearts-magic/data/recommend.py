"""
data/recommend.py - the rule-based "Mehndi Style Guide".

This is NOT a connected AI service. It is a transparent scoring system that runs
locally: each answer adds points to design categories, and the highest scores win.
(If you later connect a real AI API, keep its key in .env - never in the source.)
"""

# How many points each answer adds to each gallery category.
SCORES = {
    "style": {
        "traditional": {"traditional": 3, "bridal": 1},
        "modern": {"arabic": 3, "minimal": 1},
        "fusion": {"arabic": 2, "traditional": 1, "bridal": 1},
    },
    "detail": {
        "simple": {"minimal": 3, "arabic": 1},
        "medium": {"arabic": 2, "traditional": 1, "minimal": 1},
        "intricate": {"bridal": 3, "traditional": 2},
    },
    "occasion": {
        "bridal": {"bridal": 4},
        "engagement": {"minimal": 3, "arabic": 1},
        "reception": {"arabic": 2, "bridal": 1, "minimal": 1},
        "guest": {"minimal": 2, "arabic": 2},
    },
    "coverage": {
        "fingers": {"minimal": 3},
        "hands": {"arabic": 2, "minimal": 1, "traditional": 1},
        "forearms": {"arabic": 1, "traditional": 2, "bridal": 1},
        "full": {"bridal": 3, "traditional": 1},
    },
}

LABELS = {"bridal": "Bridal", "arabic": "Arabic", "traditional": "Traditional Indian", "minimal": "Minimal & Engagement"}

SERVICE_BY_OCCASION = {
    "bridal": "full-bridal", "engagement": "engagement", "reception": "reception", "guest": "guest-family",
}

QUESTIONS = [
    {"name": "style", "label": "Which style feels like you?", "options": [
        ("traditional", "Traditional - classic Indian motifs"), ("modern", "Modern - open, flowing designs"),
        ("fusion", "A fusion of both")]},
    {"name": "detail", "label": "How detailed should the pattern be?", "options": [
        ("simple", "Simple and light"), ("medium", "Balanced"), ("intricate", "Intricate and dense")]},
    {"name": "occasion", "label": "What is the occasion?", "options": [
        ("bridal", "Bridal / wedding"), ("engagement", "Engagement"), ("reception", "Reception"),
        ("guest", "Guest or family")]},
    {"name": "coverage", "label": "How much coverage do you prefer?", "options": [
        ("fingers", "Fingers and wrist only"), ("hands", "Hands to the wrist"),
        ("forearms", "Hands to mid-forearm"), ("full", "Elbow-length hands and feet")]},
]

COVERAGE_TIPS = {
    "fingers": "A delicate finger-and-wrist design takes about an hour.",
    "hands": "Hands-to-wrist designs balance detail and time, and suit most outfits.",
    "forearms": "Mid-forearm designs show beautifully with short or three-quarter sleeves.",
    "full": "Elbow-length work with feet is the classic bridal canvas - plan a long, relaxed session.",
}

REASONS = {
    "bridal": "Dense, story-rich designs with signature motifs - made for the main event.",
    "arabic": "Flowing vines and open spaces that look elegant and contemporary.",
    "traditional": "Classic jaali, paisley and mandala work rooted in Indian wedding tradition.",
    "minimal": "Light, graceful designs that frame rings and jewellery without overwhelming them.",
}


def recommend(answers):
    """
    answers: dict with keys style, detail, occasion, coverage.
    Returns a dict, or None if any answer is missing/invalid.
    """
    totals = {key: 0 for key in LABELS}
    for question, options in SCORES.items():
        choice = answers.get(question)
        if choice not in options:
            return None
        for category, points in options[choice].items():
            totals[category] += points

    ranked = sorted(totals.items(), key=lambda item: (-item[1], item[0]))
    (top, _), (second, _) = ranked[0], ranked[1]
    return {
        "top": top, "top_label": LABELS[top], "top_reason": REASONS[top],
        "second": second, "second_label": LABELS[second], "second_reason": REASONS[second],
        "tip": COVERAGE_TIPS[answers["coverage"]],
        "service_id": SERVICE_BY_OCCASION[answers["occasion"]],
    }
