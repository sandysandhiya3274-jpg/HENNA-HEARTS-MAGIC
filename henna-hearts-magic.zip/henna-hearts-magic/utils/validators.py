"""
utils/validators.py - server-side validation for every form.

Never trust the browser: HTML attributes help honest visitors, but anybody can
bypass them, so every rule is checked again here. Each function returns:
    (clean_data, errors)
where `errors` is a dict {field_name: "message"}. Empty dict = valid.
"""
import re
from datetime import date, datetime, timedelta

from data.site_data import EVENT_TYPES, SERVICES, TIME_SLOTS

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$")
MAX_DAYS_AHEAD = 730  # bookings accepted up to two years ahead
SERVICE_IDS = {s["id"] for s in SERVICES} | {"advice"}
CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_text(value):
    """Trim whitespace and strip invisible control characters."""
    return CONTROL_CHARS.sub("", (value or "")).strip()


def normalize_phone(raw):
    """
    Accepts common Indian mobile formats (9876543210, +91 98765 43210, 098765-43210)
    and returns the plain 10 digits, or None if it is not a valid mobile number.
    """
    digits = re.sub(r"[\s\-().]", "", raw or "")
    for prefix in ("+91", "0091"):
        if digits.startswith(prefix):
            digits = digits[len(prefix):]
            break
    else:
        if digits.startswith("91") and len(digits) == 12:
            digits = digits[2:]
        elif digits.startswith("0") and len(digits) == 11:
            digits = digits[1:]
    return digits if re.fullmatch(r"[6-9]\d{9}", digits) else None


def _check_name(value, errors):
    if len(value) < 2 or len(value) > 80:
        errors["full_name"] = "Please enter your full name (2-80 characters)."
    elif not all(ch.isalpha() or ch in " .'-" for ch in value) or sum(ch.isalpha() for ch in value) < 2:
        errors["full_name"] = "Names can only contain letters, spaces, dots, hyphens and apostrophes."


def _check_email(value, errors, field="email"):
    if not value or len(value) > 120 or not EMAIL_RE.match(value):
        errors[field] = "Please enter a valid email address, e.g. name@example.com."


def validate_booking(form, today=None):
    """Validate the bridal booking form."""
    today = today or date.today()
    errors = {}
    clean = {
        "full_name": clean_text(form.get("full_name")),
        "email": clean_text(form.get("email")).lower(),
        "phone": "",
        "event_type": clean_text(form.get("event_type")),
        "event_date": clean_text(form.get("event_date")),
        "preferred_time": clean_text(form.get("preferred_time")),
        "location": clean_text(form.get("location")),
        "guest_count": 0,
        "service": clean_text(form.get("service")),
        "notes": clean_text(form.get("notes")),
    }

    _check_name(clean["full_name"], errors)
    _check_email(clean["email"], errors)

    phone = normalize_phone(form.get("phone"))
    if phone:
        clean["phone"] = phone
    else:
        errors["phone"] = "Please enter a valid 10-digit Indian mobile number (starting with 6-9)."

    if clean["event_type"] not in EVENT_TYPES:
        errors["event_type"] = "Please choose an event type from the list."

    try:
        event_day = datetime.strptime(clean["event_date"], "%Y-%m-%d").date()
        if event_day < today:
            errors["event_date"] = "The event date cannot be in the past."
        elif event_day > today + timedelta(days=MAX_DAYS_AHEAD):
            errors["event_date"] = "Please choose a date within the next two years."
    except ValueError:
        errors["event_date"] = "Please choose a valid event date."

    if clean["preferred_time"] not in TIME_SLOTS:
        errors["preferred_time"] = "Please choose a preferred appointment time."

    if len(clean["location"]) < 3 or len(clean["location"]) > 200:
        errors["location"] = "Please tell us the event location (3-200 characters)."

    try:
        count = int(clean_text(form.get("guest_count")))
        if not 1 <= count <= 500:
            raise ValueError
        clean["guest_count"] = count
    except ValueError:
        errors["guest_count"] = "Please enter the number of people (between 1 and 500)."

    if clean["service"] not in SERVICE_IDS:
        errors["service"] = "Please choose a service or package."

    if len(clean["notes"]) > 1000:
        errors["notes"] = "Additional requirements can be at most 1000 characters."

    return clean, errors


def validate_enquiry(form):
    """Validate the contact enquiry form."""
    errors = {}
    clean = {
        "name": clean_text(form.get("name")),
        "email": clean_text(form.get("email")).lower(),
        "phone": "",
        "message": clean_text(form.get("message")),
    }
    if len(clean["name"]) < 2 or len(clean["name"]) > 80:
        errors["name"] = "Please enter your name (2-80 characters)."
    _check_email(clean["email"], errors)

    raw_phone = clean_text(form.get("phone"))
    if raw_phone:  # phone is optional on the contact form
        phone = normalize_phone(raw_phone)
        if phone:
            clean["phone"] = phone
        else:
            errors["phone"] = "That mobile number looks incorrect. Leave it blank or use 10 digits."

    if len(clean["message"]) < 10 or len(clean["message"]) > 1500:
        errors["message"] = "Please write a message of 10-1500 characters."
    return clean, errors
