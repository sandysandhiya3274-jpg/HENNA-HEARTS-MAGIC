"""
utils/csrf.py - a tiny, easy-to-read CSRF (cross-site request forgery) shield.

How it works:
  1. Each visitor's session gets a random secret token.
  2. Every <form method="post"> includes that token in a hidden field
     (templates call {{ csrf_field() }}).
  3. Before any POST request is handled, we check the submitted token matches
     the one in the session. A malicious site cannot read our token, so it
     cannot forge a valid form submission.
"""
import hmac
import secrets

from flask import abort, request, session
from markupsafe import Markup

FIELD_NAME = "csrf_token"


def get_token():
    """Return this visitor's CSRF token, creating one if needed."""
    if FIELD_NAME not in session:
        session[FIELD_NAME] = secrets.token_hex(32)
    return session[FIELD_NAME]


def csrf_field():
    """HTML for the hidden input - used inside templates."""
    return Markup('<input type="hidden" name="%s" value="%s">' % (FIELD_NAME, get_token()))


def _check_request():
    """Runs before every request; rejects unsafe methods with a bad/missing token."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    sent = request.form.get(FIELD_NAME, "")
    expected = session.get(FIELD_NAME, "")
    if not expected or not hmac.compare_digest(sent, expected):
        abort(400, description="Your form session expired. Please go back, refresh the page and try again.")


def init_app(app):
    """Attach CSRF protection to the Flask app."""
    if app.config.get("CSRF_ENABLED", True):
        app.before_request(_check_request)
    app.jinja_env.globals["csrf_field"] = csrf_field
