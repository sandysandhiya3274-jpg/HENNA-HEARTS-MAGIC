"""
config.py - all settings in one place.

Secrets and business details come from environment variables (or a local ".env"
file) so they are never hard-coded in the source code.
"""
import os
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")  # does nothing if the file doesn't exist


def _env_bool(name, default=False):
    """Read a true/false setting such as SESSION_COOKIE_SECURE=true."""
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


APP_ENV = os.getenv("APP_ENV", "development").lower()


class Config:
    # --- Security -----------------------------------------------------------
    APP_ENV = APP_ENV
    SECRET_KEY = os.getenv("SECRET_KEY")  # app.py refuses to start in production without it
    SESSION_COOKIE_HTTPONLY = True        # JavaScript cannot read the session cookie
    SESSION_COOKIE_SAMESITE = "Lax"       # helps block cross-site request forgery
    SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE", APP_ENV == "production")
    PERMANENT_SESSION_LIFETIME = timedelta(hours=2)  # admin is logged out after 2 hours
    MAX_CONTENT_LENGTH = 64 * 1024        # reject request bodies bigger than 64 KB

    # --- Database -----------------------------------------------------------
    DATABASE_PATH = os.getenv("DATABASE_PATH") or str(BASE_DIR / "database" / "henna_hearts.db")

    # --- Admin login throttling (failed attempts per IP address) ------------
    LOGIN_MAX_ATTEMPTS = 5
    LOGIN_LOCKOUT_MINUTES = 15

    # --- Business details (shown in header, footer, contact page, etc.) -----
    TIMEZONE = os.getenv("TIMEZONE", "Asia/Kolkata")
    SITE_URL = os.getenv("SITE_URL", "http://127.0.0.1:5000").rstrip("/")
    BUSINESS = {
        "name": os.getenv("BUSINESS_NAME", "Henna Hearts Magic"),
        "artist": os.getenv("ARTIST_NAME", "Your Artist Name"),
        "phone": os.getenv("BUSINESS_PHONE", "+91 98765 43210"),
        "whatsapp": "".join(ch for ch in os.getenv("WHATSAPP_NUMBER", "919876543210") if ch.isdigit()),
        "email": os.getenv("BUSINESS_EMAIL", "hello@example.com"),
        "instagram": os.getenv("INSTAGRAM_URL", "https://www.instagram.com/your_instagram_handle"),
        "address": os.getenv("BUSINESS_ADDRESS", "Studio address, Your Area, Chennai, Tamil Nadu 600001"),
        "hours": [h.strip() for h in os.getenv(
            "OPENING_HOURS", "Mon-Sat: 9:00 AM - 7:00 PM; Sun: By appointment").split(";") if h.strip()],
        "map_embed_url": os.getenv("MAP_EMBED_URL", ""),
    }
